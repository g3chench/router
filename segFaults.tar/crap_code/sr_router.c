/**********************************************************************
 * file:  sr_router.c
 * date:  Mon Feb 18 12:50:42 PST 2002
 * Contact: casado@stanford.edu
 *
 * Description:
 *
 * This file contains all the functions that interact directly
 * with the routing table, as well as the main entry method
 * for routing.
 *
 **********************************************************************/

#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "sr_if.h"
#include "sr_rt.h"
#include "sr_ip.h"
#include "sr_icmp.h"
#include "sr_protocol.h"
#include "sr_arpcache.h"
#include "sr_utils.h"
#include "sr_router.h" 
/*---------------------------------------------------------------------
 * Method: sr_init(void)
 * Scope:  Global
 *
 * Initialize the routing subsystem
 *
 *---------------------------------------------------------------------*/

void sr_init(struct sr_instance* sr) {
	/* REQUIRES */
	assert(sr);

	/* Initialize cache and cache cleanup thread */
	sr_arpcache_init(&(sr->cache));

	pthread_attr_init(&(sr->attr));
	pthread_attr_setdetachstate(&(sr->attr), PTHREAD_CREATE_JOINABLE);
	pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
	pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
	pthread_t thread;

	pthread_create(&thread, &(sr->attr), sr_arpcache_timeout, sr);

	/* Add initialization code here! */

} /* -- sr_init -- */

/*---------------------------------------------------------------------
 * Method: sr_handlepacket(uint8_t* p,char* interface)
 * Scope:  Global
 *
 * This method is called each time the router receives a packet on the
 * interface.  The packet buffer, the packet length and the receiving
 * interface are passed in as parameters. The packet is complete with
 * ethernet headers.
 *
 * Note: Both the packet buffer and the character's memory are handled
 * by sr_vns_comm.c that means do NOT delete either.  Make a copy of the
 * packet instead if you intend to keep it around beyond the scope of
 * the method call.
 *
 *---------------------------------------------------------------------*/

void sr_handlepacket(struct sr_instance* sr, uint8_t * packet, unsigned int len, char* interface) 
{
	/* REQUIRES */
	assert(sr);
	assert(packet);
	assert(interface);

	printf("*** -> Received packet of length %d \n",len);

	/* fill in code here */
	struct sr_if *iface = sr_get_interface(sr, interface);

	sr_ethernet_hdr_t *eth_hdr = (sr_ethernet_hdr_t *)packet;

	uint16_t ether_type = ntohs(eth_hdr->ether_type);

	if (ether_type == ethertype_arp) {
		printf("recieved ethernet frame containing ARP packet!\n");
		sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));

		if (!sr_get_if_from_ip(arp_hdr->ar_tip, sr->if_list)) {
			fprintf(stderr, "ERROR: this ARP packet is not for us.\n");
			return;
		}

		switch (ntohs(arp_hdr->ar_op)) {
			case arp_op_request: {
				send_arp_reply(sr, packet, len, iface);
			
			}
			case arp_op_reply: {
				printf("Recieved an ARP reply packet!\n");
				
				/* get the request entry with the most matches*/
				struct sr_arpreq *req_entry = sr_arpcache_insert(&(sr->cache), arp_hdr->ar_sha, arp_hdr->ar_sip);


				printf ("req_entry: ");
				print_addr_ip_int(req_entry->ip);
				struct sr_packet *current_packet = req_entry->packets;
				while (current_packet) {
					/* construct outgoing ethernet frame to send to forward out*/
					uint8_t *eth_frame = current_packet->buf;
					sr_ethernet_hdr_t *eth_hdr = (sr_ethernet_hdr_t *) eth_frame;

					/* construct ethernet header ith ARP request*/
					struct sr_if *if_out = sr_get_interface(sr, current_packet->iface);
					memcpy(eth_hdr->ether_shost, if_out->addr, ETHER_ADDR_LEN);
					memcpy(eth_hdr->ether_dhost, arp_hdr->ar_sha, ETHER_ADDR_LEN);
					
					/*print_hdrs(eth_frame, current_packet->len);*/
					printf("sending an arp packet to outgoing iface");
					sr_send_packet(sr, eth_frame, current_packet->len, current_packet->iface);
					current_packet = current_packet->next;
				}
				sr_arpreq_destroy(&(sr->cache), req_entry);
			
			}
			default: {
				fprintf(stderr, "The inputted ARP type is invalid\n");
			}
		}
	}
	else if (ether_type == ethertype_ip) {
		printf("recieved an incoming IP packet!\n");
		
		struct sr_ip_hdr *ip_hdr = (struct sr_ip_hdr *)(packet + sizeof(sr_ethernet_hdr_t));

		/* perform sanity check: compare checksums*/
		uint16_t expected_sum = ip_hdr->ip_sum;
		ip_hdr->ip_sum = 0;
		int ip_hl = ip_hdr->ip_hl * 4;
		uint16_t actual_sum = cksum(ip_hdr, ip_hl);
		unsigned int min_packet_len = sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t);
		if (actual_sum != expected_sum || len < min_packet_len) {
			fprintf(stderr, "The packet's checksum doesn't match the expected checksum.\n");
			return;
		}
		ip_hdr->ip_sum = expected_sum;

		if (sr_get_if_from_ip(ip_hdr->ip_dst, sr->if_list)) {
			printf("this IP packet is FOR US!!!\n");

			uint8_t ip_protocol = ip_hdr->ip_p;
			if (ip_protocol == ip_protocol_icmp)
			{
				sr_icmp_hdr_t *icmp_hdr = (sr_icmp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
				if (icmp_hdr->icmp_type == 8 && icmp_hdr->icmp_code == 0) { /* ICMP echo request */
					printf("Got an ICP echo request!\n");
					/* Sancheck: checksum */
					uint16_t expected_sum_icmp = icmp_hdr->icmp_sum;
					icmp_hdr->icmp_sum = 0;
					uint16_t calculated_checksum_icmp = cksum(icmp_hdr, ntohs(ip_hdr->ip_len) - ip_hl);
					
					if (expected_sum_icmp == calculated_checksum_icmp) {
						icmp_hdr->icmp_sum = expected_sum_icmp; /* Restore checksum */
						send_icmp_echo_reply(sr, packet, len, 0);

					}
					else {
						fprintf(stderr, "ERROR: checksums mismatch\n");
					}
				}
			}
			else if (ip_protocol == ip_protocol_udp || ip_protocol == ip_protocol_tcp) {
				send_icmp_port_unreachable(sr, packet, 0, 0);
			}
			else {
				fprintf(stderr, "The given IP protocol is inalid.\n");
			}
		}
		else {
			fprintf(stderr, "PACKET ISN'T FOR US! FWD  IT TO NEXT HOPE!\n");
			fwd_next_hop(sr, packet, len);
		}
	}
	else {
		printf("Unsupported packet\n");
	}
}